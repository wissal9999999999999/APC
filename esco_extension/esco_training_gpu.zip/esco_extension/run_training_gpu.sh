#!/usr/bin/env bash
set -euo pipefail

python esco_extension/train_mnrl.py \
  --data-dir esco_extension/combined \
  --output-dir esco_extension/checkpoints/esco_extended_mnrl \
  --model dangvantuan/sentence-camembert-large \
  --epochs 3 \
  --batch-size 8 \
  --learning-rate 2e-5 \
  --warmup-ratio 0.1 \
  --seed 42
